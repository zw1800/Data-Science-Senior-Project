We are building the non-profit AI4Finance foundation for open-source projects, in the AI for Finance field.

Your support will encourage the core team to release more practical codes. Thx.
